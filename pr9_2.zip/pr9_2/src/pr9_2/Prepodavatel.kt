package pr9_2

open class Prepodavatel(
    information: String,
    kabiturient: String,
    kfacultet:String,
    kexam:String,
    kprepod:String,
    Date: String,
    predmet: String,
    kaninet: String,
    ochenka: Int,
    var etagh: Int

) : Exam(information, kabiturient, kfacultet, kexam, kprepod, Date, predmet, kaninet, ochenka)
{

    override fun Info(vs: Vsypitel_Exam) {
        super.Info(vs)
        println("Этаж: $etagh")
    }

    fun PrepodSostav()
    {
        println("Состав преподавателей: ")
        println("Маркони Б.С - Архитектура")
        println("Бертули В.Д - Программирование")
        println("Арбо С.Б - Дизайн")
    }


}