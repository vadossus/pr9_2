package Autobaza

class Repair(val voditel: Voditel) {
    fun repairCar() {
        println("${voditel.name} ремонтирует автомобиль")
    }
}