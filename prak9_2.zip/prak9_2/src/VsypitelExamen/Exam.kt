package VsypitelExamen

open class Exam (val predmet: String, var bal: Int) {

    fun InfoExams()
    {
        println("Информация о экзаменах:")
        println("Математика")
        println("Черчение")
        println("Информатика")
    }

    fun Prepdavatel()
    {
        println("Состав преподавателей: ")
        println("Математика - Александр Жуковский")
        println("Черчение - Василий Дроздов")
        println("Информатика - Дмитрий Корпов")
    }


}