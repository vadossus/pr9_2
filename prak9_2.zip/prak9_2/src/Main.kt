import VsypitelExamen.*
import Autobaza.*

// Вариант 5 - Вступительный экзамен
// Вариает 1 - Автобаза

fun main() {
    try {
        println("Что вы хотите выбрать:\n1-Вступительный экзамен\n2-Автобаза")
        var choose = readLine()!!.toInt()
        if (choose == 1)
        {
            val facultet = Facultet("Математика")
            val ch = Chelovek("", facultet)
            val prepod = Prepdavatel("Александр Жуковский", facultet)
            val abiturient1 = Abiturient("",facultet)
            val abiturient2 = Abiturient("",facultet)
            var ex = Exam("",0)

            abiturient1.Input()
            abiturient2.Input()

            prepod.OperedelitAbutyrienta(abiturient1)
            prepod.OperedelitAbutyrienta(abiturient2)
            println("Средний балл ${abiturient1.name}: ${abiturient1.GetSredBall()}")
            println("Средний балл ${abiturient2.name}: ${abiturient2.GetSredBall()}")

            println("")
            ex.InfoExams()
            println("")
            ex.Prepdavatel()
        }
        else if (choose == 2)
        {
            val dispatcher = Dispatcher("Владимир")
            val voditel = Voditel("")
            val car = Car("")
            val person = Person("Александр")
            val trip = Trip(voditel,car)

            voditel.inputName()
            car.CarInput(car)
            Thread.sleep(2000)
            trip.InfoTrip(voditel,car,dispatcher)
            Thread.sleep(2000)


            person.PersonMakeZaiyavky()
            Thread.sleep(2000)
            dispatcher.NaznachitTrip(voditel, car)
            Thread.sleep(2000)
            voditel.RemontProsba()
            Thread.sleep(2000)

            val repair = Repair(voditel)
            repair.repairCar()
            Thread.sleep(2000)

            dispatcher.OtstranitVoditelya(voditel)

        }
        else
        {
            println("Нужно выбрать 1 или 2, других вариантов нету")
            System.exit(0)
        }
    }
    catch (ex:Exception)
    {
        println("Ошибка: ${ex.message}")
    }



}