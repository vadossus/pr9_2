package pr9_2

open class Abiturient (var Information: String, kabiturient: String, var Date: String, kfacultet:String, kexam:String, kprepod:String):Vsypitel_Exam(kabiturient,kfacultet,kexam,kprepod){

    fun Input(ab: Abiturient) {
        println("Введите информацию: ")
        ab.Information = readLine()!!.toString()
        println("Введите дату экзамена: ")
        ab.Date = readLine()!!.toString()

    }
    fun Info(ab: Abiturient)
    {
        super.Info(ab)
        println("Информация о абитуриенте: ${ab.Information}")
        println("Дата: ${ab.Date}")
    }

    fun ChooseTheExam()
    {
        println("Введите в какой факультет вы хотите поступать: ")
        var choose = readLine()!!.toString()


        if (choose == "Архитектура")
        {
            var exam = "Черчение"
            println("Вы выбрали $choose: Экзамен: $exam")
        }
        else if (choose == "Дизайн")
        {
            var exam = "Творческое испытание, рисунок"
            println("Вы выбрали $choose: Экзамен: $exam")
        }
        else if (choose == "Программирование")
        {
            var exam = "Математика"
            println("Вы выбрали $choose: Экзамен: $exam")
        }
        else
        {
            println("Такого варианта нет.");
        }
    }




}