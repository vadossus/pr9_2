package Autobaza

class Dispatcher(name: String) : Person(name)
{
    fun NaznachitTrip(voditel: Voditel, car: Car) {
        val trip = Trip(voditel, car)
        println("Диспетчер $name назначает рейс водителю ${voditel.name}")
        voditel.OtmetkaTrip(trip)
    }

    fun OtstranitVoditelya(voditel: Voditel) {
        println("Диспетчер $name отстраняет водителя ${voditel.name}")
        voditel.otstranen = true
    }
}
