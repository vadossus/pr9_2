package pr9_2

import kotlin.random.Random

open class Exam(
    information: String,
    kabiturient: String,
    kfacultet:String,
    kexam:String,
    kprepod:String,
    Date: String,
    var predmet: String,
    var kabinet: String,
    var ochenka: Int
):Facultet(information, kabiturient, kfacultet, kexam, kprepod, Date)
{
    fun Input(ex: Exam)
    {
        println("Введите кабинет: ")
        ex.kabinet = readLine()!!.toString()
        println("Введите предмет: ")
        ex.predmet = readLine()!!.toString()
    }
    override fun Info(vs: Vsypitel_Exam) {
        super.Info(vs)
        println("Предмет: $predmet")
        println("Кабинет: $kabinet")
    }


    open fun VistavlenieOchenki(ex:Exam)
    {
        val massive = IntArray(5)

        for (i in 0 until 5)
        {
            ex.ochenka = Random.nextInt(1,5)
            massive[i] = ex.ochenka
        }
        println("Оценки за экзамен: ")
        for (ochenka in massive)
        {
            println(ochenka)
        }
    }





}