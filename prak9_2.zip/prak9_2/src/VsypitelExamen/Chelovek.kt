package VsypitelExamen

open class Chelovek(var name: String, val facultet: Facultet) {
    var sredBal = 0.0

    init {
        name
        facultet
    }


}