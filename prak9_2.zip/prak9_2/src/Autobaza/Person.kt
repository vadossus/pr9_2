package Autobaza

open class Person(var name: String) {

    init {
        name
    }

    fun inputName() {
        println("Введите имя:")
        name = readLine()!!.toString()
    }

    open fun PersonMakeZaiyavky()
    {
        println("$name делает заявку")
    }
}