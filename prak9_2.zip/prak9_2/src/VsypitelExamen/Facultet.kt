package VsypitelExamen

open class Facultet(val name: String)
{
    val abiturienti = mutableListOf<Abiturient>()

    fun ZachislitAbiturienta(ab: Abiturient)
    {
        abiturienti.add(ab)
    }
}