package pr9_2

open class Facultet(
    information: String,
    kabiturient: String,
    kfacultet:String,
    kexam:String,
    kprepod:String,
    Date: String

):Abiturient(information,kabiturient,kfacultet,kexam,kprepod, Date)
{
    fun Register(ab: Abiturient, vs: Vsypitel_Exam)
    {
        try {
            println("Хотите поступить по факультету ${vs.facultet}: ")
            var choose = readLine()
            if (choose == "Да" || choose == "да")
            {
                Thread.sleep(3000)
                println("Вы успешно зарегистрировались на вступительный экзамен!")
                println("")
                println("Информация: ")
                println("Дата экзамена: ${ab.Date}")
                println("Преподаватель: ${vs.prepod}")
            }
            else
            {
                println("До свидания!")
                System.exit(0)
            }
        }
        catch (ex:Exception)
        {
            println("Ошибка: ${ex.message}")
        }



    }


}