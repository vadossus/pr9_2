package pr9_2

fun main()
{
    var b:Vsypitel_Exam = Vsypitel_Exam("","","","",)
    b.Input(b)
    var c:Abiturient = Abiturient("","","","","","")
    c.Input(c)
    c.ChooseTheExam()
    var d:Facultet = Facultet(c.Information,b.abiturient,c.Date,b.exam,b.prepod,b.facultet)
    d.Register(c,b)
    var e:Exam = Exam(c.Information,b.abiturient,b.facultet,b.exam,b.prepod,c.Date, "","",0)
    e.Input(e)
    e.VistavlenieOchenki(e)
    var l:Ochenka = Ochenka(c.Information,b.abiturient,b.facultet,b.exam,b.prepod,c.Date,e.predmet,e.kabinet,0,e.ochenka)
    try {
        println("Введите на каком этаже проводится экзамен: ")
        l.etagh = readLine()!!.toInt()
        l.VistavlenieOchenki(e)
    }
    catch (ex:Exception)
    {
        println("Ошибка: ${ex.message}")
    }
    var k:Prepodavatel = Prepodavatel(c.Information,b.abiturient,b.facultet,b.exam,b.prepod,c.Date,e.predmet,e.kabinet,l.etagh,e.ochenka)
    k.PrepodSostav()
    b.CredneeArifmet()
    println("")








}