package Autobaza

class Voditel(name: String): Person(name)
{
    var otstranen = false


    fun OtmetkaTrip(trip: Trip) {
        println("$name делает отметку, что рейс выполнен и автомобиль в хорошем состоянии")
        trip.complete()
    }

    fun RemontProsba() {
        println("$name делает заявку на ремонт автомобиля")
    }
}