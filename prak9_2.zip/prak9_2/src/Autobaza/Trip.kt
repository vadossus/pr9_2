package Autobaza

class Trip(val voditel: Voditel, val car: Car) {
    var tripname = "Москва - Санкт-Петербург"

    fun complete() {
        println("Рейс выполнен и автомобиль ${car.model} в хорошем состоянии")
    }

    fun InfoTrip(v:Voditel, car: Car, d:Dispatcher)
    {
        println("Информация о поездке: ")
        println("Водитель: ${v.name}")
        println("Модель машины: ${car.model}")
        println("Рейс: ${tripname}")
        println("Диспетчер: ${d.name}")
    }
}