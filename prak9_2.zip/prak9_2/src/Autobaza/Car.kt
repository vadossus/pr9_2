package Autobaza

class Car (var model: String) {

    fun CarInput(car: Car)
    {
        println("Введите модель машины: ")
        car.model = readLine()!!.toString()
    }

    fun CarOutput(car: Car) : String
    {
        return car.model;
    }
}