
package pr9_2

import java.util.Scanner
import kotlin.random.Random

open class Vsypitel_Exam(
    var abiturient: String,
    var facultet: String,
    var exam: String,
    var prepod: String,

)
{
    open fun Input(vs: Vsypitel_Exam)
    {
        try {
            println("Введите абитуриента: ")
            vs.abiturient = readLine().toString()
            println("Введите факультет: ")
            vs.facultet = readLine()!!.toString()
            println("Введите название экзамена: ")
            vs.exam = readLine()!!.toString()
            println("Введите ФИО преподавателя: ")
            vs.prepod = readLine()!!.toString()

        }
        catch (ex:Exception)
        {
            println("Ошибка: ${ex.message}")
        }


    }

    open fun Info(vs: Vsypitel_Exam)
    {
       println("Абитуриент: ${vs.abiturient}")
        println("Факультет: ${vs.facultet}")
        println("Экзамен: ${vs.exam}")
        println("Преподаватель: ${vs.prepod}")
    }

    fun CredneeArifmet()
    {
        try
        {
            println("Введите предмет: ")
            var predmet = readLine()

            val sc = Scanner(System.`in`)

            println("Введите кол-во оценок")
            var i = readLine()!!.toInt()

            var sum = 0
            println("Введите оценки: ")
            repeat(i)
            {
                sum += sc.nextInt()
            }


            if (sum/i == 5)
            {
                var srednee_arifmet = sum/i
                println("Среднее арифметическое: $srednee_arifmet")
                println("Вы сдали экзамен")
                println("Вы зачислены в учебное заведение")
            }
            else if (sum/i == 4)
            {
                var srednee_arifmet = sum/i
                println("Среднее арифметическое: $srednee_arifmet")
                println("Вы сдали экзамен")
                println("Вы зачислены в учебное заведение")
            }
            else if (sum/i == 3)
            {
                var srednee_arifmet = sum/i
                println("Среднее арифметическое: $srednee_arifmet")
                println("Вы сдали экзамен")
                var l = 0
                l = Random.nextInt(1,3)
                if (l == 1)
                {
                    println("Вы зачислены в учебное заведение")
                }
                else
                {
                    println("Вы не зачислены в учебное заведение")
                }
            }
            else
            {
                println("Вы не сдали экзамен")
                println("Вы не зачислены в учебное заведение")
                System.exit(0)
            }
        }
        catch (ex:Exception)
        {
            println("Ошибка: ${ex.message}")
        }

    }




}