package pr9_2

class AutoBaza {
}