package pr9_2


class Ochenka (
    information: String,
    kabiturient: String,
    kfacultet:String,
    kexam:String,
    kprepod:String,
    Date: String,
    predmet: String,
    kaninet: String,
    etagh: Int,
    ochenka: Int
) : Prepodavatel(information, kabiturient, kfacultet, kexam, kprepod, Date, predmet, kaninet, etagh, ochenka){

    override fun VistavlenieOchenki(exam: Exam)
    {
        super.Info(exam)
        println("")
        println("Все оценки: ")
        println("5 - Отлично")
        println("4 - Хорошо")
        println("3 - Удовлетворительно")
        println("2 - Неудовлетворительно")
        println("1 - Плохо")
    }



}