package VsypitelExamen

open class Abiturient(name: String, facultet: Facultet): Chelovek(name, facultet){
    val exam = mutableListOf<Exam>()

    fun RegisterExam(ex: Exam) {
        exam.add(ex)
    }

    fun getExams(): List<Exam> {
        return exam
    }

    open fun SredniBall() {

        if (exam.isEmpty())
        {
            sredBal = 0.0
        }
        else
        {
            var sum = 0
            exam.forEach { exam ->
                sum += exam.bal
            }
            sredBal = sum.toDouble()/ getExams().size
        }
    }

    fun GetSredBall(): Double {
        return sredBal;
    }

    fun Input()
    {
        try {
            println("Введите ваше имя и фамилию")
            val name = readLine()!!.toString()
            this.name = name
            val abiturient = Abiturient(name, this.facultet)

            println("Введите оценку за первый экзамен")
            val ochenka1 = readLine()!!.toInt()
            val exam1 = Exam("Предмет 1", ochenka1)
            RegisterExam(exam1)

            println("Введите оценку за второй экзамен")
            val ochenka2 = readLine()!!.toInt()
            val exam2 = Exam("Предмет 2", ochenka2)
            RegisterExam(exam2)

            facultet.ZachislitAbiturienta(abiturient)
        }
        catch (ex:Exception)
        {
            println("Ошибка: ${ex.message}")
        }
    }
}