package VsypitelExamen

open class Prepdavatel(
    name: String,
    facultet: Facultet
): Chelovek(name,facultet){

    open fun OperedelitAbutyrienta(ab: Abiturient)
    {
        ab.SredniBall()
        if (ab.sredBal in 4.0..5.0)
        {
            println("Абитуриент ${ab.name} был зачислен на факультет ${ab.facultet.name}")
        }
        else
        {
            println("Абитуриент ${ab.name} не зачислен на факультет ${ab.facultet.name}")
        }

    }
}